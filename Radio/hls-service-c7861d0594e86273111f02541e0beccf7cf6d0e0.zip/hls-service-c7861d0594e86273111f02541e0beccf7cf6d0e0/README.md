# hls-service
Nodejs base hls server
```
npm install
npm start
```

Access to url ** http://localhost:8000 ** or ** http://localhost:8000/manifest.m3u8 **